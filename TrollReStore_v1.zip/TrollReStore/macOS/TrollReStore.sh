#!/bin/sh

./idevicebackup2 -s PartialBackup --system --skip-apps restore ..

read -p "Press enter to continue..."

